﻿namespace TCPpj_main
{
    partial class CSRform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            sv_search = new Button();
            menu = new Button();
            search = new Button();
            CSmain = new Label();
            panel2 = new Panel();
            chatterbox = new Label();
            panel6 = new Panel();
            customer_information = new Panel();
            label1 = new Label();
            customer_info = new Label();
            panel9 = new Panel();
            panel8 = new Panel();
            listView1 = new ListView();
            panel7 = new Panel();
            panel5 = new Panel();
            panel4 = new Panel();
            Below_bar = new Panel();
            CStime_msg = new Label();
            CStime = new Label();
            richTextBox1 = new RichTextBox();
            imgSend = new Button();
            msgSend = new Button();
            textBox1 = new TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            customer_information.SuspendLayout();
            panel8.SuspendLayout();
            Below_bar.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Window;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(sv_search);
            panel1.Controls.Add(menu);
            panel1.Controls.Add(search);
            panel1.Controls.Add(CSmain);
            panel1.Location = new Point(0, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(768, 48);
            panel1.TabIndex = 8;
            // 
            // sv_search
            // 
            sv_search.BackgroundImageLayout = ImageLayout.Zoom;
            sv_search.FlatAppearance.BorderSize = 0;
            sv_search.FlatStyle = FlatStyle.Flat;
            sv_search.Location = new Point(693, 10);
            sv_search.Margin = new Padding(2, 2, 2, 0);
            sv_search.Name = "sv_search";
            sv_search.Size = new Size(27, 26);
            sv_search.TabIndex = 7;
            sv_search.UseVisualStyleBackColor = true;
            // 
            // menu
            // 
            menu.BackColor = Color.White;
            menu.BackgroundImageLayout = ImageLayout.Zoom;
            menu.FlatAppearance.BorderSize = 0;
            menu.FlatStyle = FlatStyle.Flat;
            menu.Location = new Point(725, 8);
            menu.Margin = new Padding(2, 2, 2, 2);
            menu.Name = "menu";
            menu.Size = new Size(31, 30);
            menu.TabIndex = 6;
            menu.UseVisualStyleBackColor = false;
            // 
            // search
            // 
            search.BackgroundImageLayout = ImageLayout.Zoom;
            search.FlatAppearance.BorderSize = 0;
            search.FlatStyle = FlatStyle.Flat;
            search.Location = new Point(688, 8);
            search.Margin = new Padding(2, 2, 2, 0);
            search.Name = "search";
            search.Size = new Size(27, 26);
            search.TabIndex = 6;
            search.UseVisualStyleBackColor = true;
            // 
            // CSmain
            // 
            CSmain.AutoSize = true;
            CSmain.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            CSmain.Location = new Point(8, 9);
            CSmain.Margin = new Padding(2, 0, 2, 0);
            CSmain.Name = "CSmain";
            CSmain.Size = new Size(131, 30);
            CSmain.TabIndex = 1;
            CSmain.Text = "상담사 이름";
            CSmain.Click += CSmain_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonHighlight;
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(chatterbox);
            panel2.Controls.Add(panel6);
            panel2.Location = new Point(0, 48);
            panel2.Margin = new Padding(2, 2, 2, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(202, 412);
            panel2.TabIndex = 19;
            // 
            // chatterbox
            // 
            chatterbox.AutoSize = true;
            chatterbox.BackColor = SystemColors.Window;
            chatterbox.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point);
            chatterbox.Location = new Point(14, 9);
            chatterbox.Margin = new Padding(2, 0, 2, 0);
            chatterbox.Name = "chatterbox";
            chatterbox.Size = new Size(74, 21);
            chatterbox.TabIndex = 22;
            chatterbox.Text = "채팅상담";
            // 
            // panel6
            // 
            panel6.BackColor = SystemColors.ControlLight;
            panel6.Location = new Point(98, -2);
            panel6.Margin = new Padding(2, 2, 2, 2);
            panel6.Name = "panel6";
            panel6.Size = new Size(101, 38);
            panel6.TabIndex = 24;
            // 
            // customer_information
            // 
            customer_information.BackColor = SystemColors.ButtonHighlight;
            customer_information.BorderStyle = BorderStyle.Fixed3D;
            customer_information.Controls.Add(label1);
            customer_information.Controls.Add(customer_info);
            customer_information.Controls.Add(panel9);
            customer_information.Controls.Add(panel8);
            customer_information.Controls.Add(panel7);
            customer_information.Controls.Add(panel5);
            customer_information.Controls.Add(panel4);
            customer_information.Location = new Point(566, 48);
            customer_information.Margin = new Padding(2, 2, 2, 2);
            customer_information.Name = "customer_information";
            customer_information.Size = new Size(202, 412);
            customer_information.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Window;
            label1.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(13, 213);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(74, 21);
            label1.TabIndex = 26;
            label1.Text = "상담이력";
            // 
            // customer_info
            // 
            customer_info.AutoSize = true;
            customer_info.BackColor = SystemColors.Window;
            customer_info.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point);
            customer_info.Location = new Point(13, 9);
            customer_info.Margin = new Padding(2, 0, 2, 0);
            customer_info.Name = "customer_info";
            customer_info.Size = new Size(74, 21);
            customer_info.TabIndex = 25;
            customer_info.Text = "고객정보";
            // 
            // panel9
            // 
            panel9.BackColor = SystemColors.InactiveCaption;
            panel9.BorderStyle = BorderStyle.FixedSingle;
            panel9.Location = new Point(5, 246);
            panel9.Margin = new Padding(2, 2, 2, 2);
            panel9.Name = "panel9";
            panel9.Size = new Size(191, 159);
            panel9.TabIndex = 23;
            // 
            // panel8
            // 
            panel8.BackColor = SystemColors.InactiveCaption;
            panel8.Controls.Add(listView1);
            panel8.Location = new Point(5, 40);
            panel8.Margin = new Padding(2, 2, 2, 2);
            panel8.Name = "panel8";
            panel8.Size = new Size(191, 155);
            panel8.TabIndex = 22;
            // 
            // listView1
            // 
            listView1.Location = new Point(2, 2);
            listView1.Margin = new Padding(2, 2, 2, 2);
            listView1.Name = "listView1";
            listView1.Size = new Size(188, 153);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // panel7
            // 
            panel7.BackColor = SystemColors.ControlDarkDark;
            panel7.Location = new Point(5, 200);
            panel7.Margin = new Padding(2, 2, 2, 2);
            panel7.Name = "panel7";
            panel7.Size = new Size(191, 2);
            panel7.TabIndex = 25;
            // 
            // panel5
            // 
            panel5.BackColor = SystemColors.ControlLight;
            panel5.Location = new Point(99, 206);
            panel5.Margin = new Padding(2, 2, 2, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(101, 38);
            panel5.TabIndex = 23;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ControlLight;
            panel4.Location = new Point(98, -2);
            panel4.Margin = new Padding(2, 2, 2, 2);
            panel4.Name = "panel4";
            panel4.Size = new Size(101, 38);
            panel4.TabIndex = 22;
            // 
            // Below_bar
            // 
            Below_bar.BackColor = SystemColors.Control;
            Below_bar.Controls.Add(CStime_msg);
            Below_bar.Controls.Add(CStime);
            Below_bar.Location = new Point(0, 458);
            Below_bar.Margin = new Padding(2, 2, 2, 2);
            Below_bar.Name = "Below_bar";
            Below_bar.Size = new Size(768, 40);
            Below_bar.TabIndex = 21;
            // 
            // CStime_msg
            // 
            CStime_msg.Location = new Point(2, 20);
            CStime_msg.Margin = new Padding(2, 0, 2, 0);
            CStime_msg.Name = "CStime_msg";
            CStime_msg.Size = new Size(271, 17);
            CStime_msg.TabIndex = 0;
            CStime_msg.Text = "[실시간 채팅상담] 10:00~18:00 (점심 13:00~14:00)";
            // 
            // CStime
            // 
            CStime.AutoSize = true;
            CStime.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point);
            CStime.Location = new Point(2, 5);
            CStime.Margin = new Padding(2, 0, 2, 0);
            CStime.Name = "CStime";
            CStime.Size = new Size(107, 15);
            CStime.TabIndex = 0;
            CStime.Text = "고객센터 운영시간";
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(203, 50);
            richTextBox1.Margin = new Padding(2, 2, 2, 2);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(363, 374);
            richTextBox1.TabIndex = 22;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // imgSend
            // 
            imgSend.BackColor = SystemColors.Window;
            imgSend.BackgroundImage = Properties.Resources.사진보내기_버튼;
            imgSend.BackgroundImageLayout = ImageLayout.Zoom;
            imgSend.FlatStyle = FlatStyle.Popup;
            imgSend.Location = new Point(201, 426);
            imgSend.Margin = new Padding(2, 2, 2, 2);
            imgSend.Name = "imgSend";
            imgSend.Size = new Size(37, 33);
            imgSend.TabIndex = 25;
            imgSend.UseVisualStyleBackColor = false;
            imgSend.Click += imgSend_Click;
            // 
            // msgSend
            // 
            msgSend.BackColor = SystemColors.ControlLightLight;
            msgSend.BackgroundImage = Properties.Resources.보내기_버튼;
            msgSend.BackgroundImageLayout = ImageLayout.Zoom;
            msgSend.FlatStyle = FlatStyle.Flat;
            msgSend.Location = new Point(530, 426);
            msgSend.Margin = new Padding(2, 2, 2, 2);
            msgSend.Name = "msgSend";
            msgSend.Size = new Size(39, 33);
            msgSend.TabIndex = 24;
            msgSend.UseVisualStyleBackColor = false;
            msgSend.Click += msgSend_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(237, 426);
            textBox1.Margin = new Padding(2, 2, 2, 2);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(293, 34);
            textBox1.TabIndex = 23;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // CSRform
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(768, 499);
            Controls.Add(imgSend);
            Controls.Add(msgSend);
            Controls.Add(textBox1);
            Controls.Add(richTextBox1);
            Controls.Add(Below_bar);
            Controls.Add(customer_information);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Margin = new Padding(2, 2, 2, 2);
            Name = "CSRform";
            Text = "CSRform";
            Load += CSRform_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            customer_information.ResumeLayout(false);
            customer_information.PerformLayout();
            panel8.ResumeLayout(false);
            Below_bar.ResumeLayout(false);
            Below_bar.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button sv_search;
        private Button menu;
        private Button search;
        private Label CSmain;
        private Panel panel2;
        private Label chatterbox;
        private Panel panel6;
        private Panel customer_information;
        private Label label1;
        private Label customer_info;
        private Panel panel9;
        private Panel panel8;
        private ListView listView1;
        private Panel panel7;
        private Panel panel5;
        private Panel panel4;
        private Panel Below_bar;
        private Label CStime_msg;
        private Label CStime;
        private RichTextBox richTextBox1;
        private Button imgSend;
        private Button msgSend;
        private TextBox textBox1;
    }
}