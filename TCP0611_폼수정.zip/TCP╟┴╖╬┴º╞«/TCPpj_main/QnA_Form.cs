﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPpj_main
{
    public partial class QnA_Form : Form
    {
        public QnA_Form()
        {
            InitializeComponent();
        }

        private void shipment_Q_Click(object sender, EventArgs e)   //배송 관련 버튼
        {
            //버튼 눌렀을 때 답변이 나오게끔 설정하고 싶음..!
            //label만 작성해둠
        }

        private void take_back_Q_Click(object sender, EventArgs e)  //반품 교환버튼
        {

        }

        private void AS_Q_Click(object sender, EventArgs e) //A/S기간 버튼
        {

        }
    }
}
