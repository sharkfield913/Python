﻿namespace ServerForm
{
    partial class serverform_chatting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            sv_search = new Button();
            CSmain = new Label();
            Below_bar = new Panel();
            customer_information = new Panel();
            label1 = new Label();
            customer_info = new Label();
            panel9 = new Panel();
            panel8 = new Panel();
            panel7 = new Panel();
            panel5 = new Panel();
            panel4 = new Panel();
            listView1 = new ListView();
            SVstart = new Button();
            panel2 = new Panel();
            SVstop = new Button();
            chatterbox = new Label();
            imgSend = new Button();
            msgSend = new Button();
            textBox1 = new TextBox();
            panel3 = new Panel();
            richTextBox1 = new RichTextBox();
            folderBrowserDialog1 = new FolderBrowserDialog();
            panel1.SuspendLayout();
            customer_information.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Window;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(sv_search);
            panel1.Controls.Add(CSmain);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(768, 48);
            panel1.TabIndex = 7;
            panel1.Paint += panel1_Paint;
            // 
            // sv_search
            // 
            sv_search.BackgroundImage = Properties.Resources.검색_버튼;
            sv_search.BackgroundImageLayout = ImageLayout.Zoom;
            sv_search.FlatAppearance.BorderSize = 0;
            sv_search.FlatStyle = FlatStyle.Flat;
            sv_search.Location = new Point(693, 10);
            sv_search.Margin = new Padding(2, 2, 2, 0);
            sv_search.Name = "sv_search";
            sv_search.Size = new Size(0, 0);
            sv_search.TabIndex = 7;
            sv_search.UseVisualStyleBackColor = true;
            // 
            // CSmain
            // 
            CSmain.AutoSize = true;
            CSmain.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            CSmain.Location = new Point(8, 9);
            CSmain.Margin = new Padding(2, 0, 2, 0);
            CSmain.Name = "CSmain";
            CSmain.Size = new Size(114, 30);
            CSmain.TabIndex = 1;
            CSmain.Text = "CS_Server";
            // 
            // Below_bar
            // 
            Below_bar.BackColor = SystemColors.Control;
            Below_bar.Location = new Point(0, 458);
            Below_bar.Margin = new Padding(2, 2, 2, 2);
            Below_bar.Name = "Below_bar";
            Below_bar.Size = new Size(768, 40);
            Below_bar.TabIndex = 16;
            // 
            // customer_information
            // 
            customer_information.BackColor = SystemColors.ButtonHighlight;
            customer_information.BorderStyle = BorderStyle.Fixed3D;
            customer_information.Controls.Add(label1);
            customer_information.Controls.Add(customer_info);
            customer_information.Controls.Add(panel9);
            customer_information.Controls.Add(panel8);
            customer_information.Controls.Add(panel7);
            customer_information.Controls.Add(panel5);
            customer_information.Controls.Add(panel4);
            customer_information.Location = new Point(566, 48);
            customer_information.Margin = new Padding(2, 2, 2, 2);
            customer_information.Name = "customer_information";
            customer_information.Size = new Size(202, 412);
            customer_information.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Window;
            label1.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(13, 213);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(74, 21);
            label1.TabIndex = 26;
            label1.Text = "상담이력";
            // 
            // customer_info
            // 
            customer_info.AutoSize = true;
            customer_info.BackColor = SystemColors.Window;
            customer_info.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point);
            customer_info.Location = new Point(13, 9);
            customer_info.Margin = new Padding(2, 0, 2, 0);
            customer_info.Name = "customer_info";
            customer_info.Size = new Size(74, 21);
            customer_info.TabIndex = 25;
            customer_info.Text = "고객정보";
            // 
            // panel9
            // 
            panel9.BackColor = SystemColors.InactiveCaption;
            panel9.BorderStyle = BorderStyle.FixedSingle;
            panel9.Location = new Point(5, 246);
            panel9.Margin = new Padding(2, 2, 2, 2);
            panel9.Name = "panel9";
            panel9.Size = new Size(191, 159);
            panel9.TabIndex = 23;
            // 
            // panel8
            // 
            panel8.BackColor = SystemColors.InactiveCaption;
            panel8.Location = new Point(5, 40);
            panel8.Margin = new Padding(2, 2, 2, 2);
            panel8.Name = "panel8";
            panel8.Size = new Size(191, 155);
            panel8.TabIndex = 22;
            panel8.Paint += panel8_Paint;
            // 
            // panel7
            // 
            panel7.BackColor = SystemColors.ControlDarkDark;
            panel7.Location = new Point(5, 200);
            panel7.Margin = new Padding(2, 2, 2, 2);
            panel7.Name = "panel7";
            panel7.Size = new Size(191, 2);
            panel7.TabIndex = 25;
            // 
            // panel5
            // 
            panel5.BackColor = SystemColors.ControlLight;
            panel5.Location = new Point(99, 206);
            panel5.Margin = new Padding(2, 2, 2, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(101, 38);
            panel5.TabIndex = 23;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ControlLight;
            panel4.Location = new Point(98, -2);
            panel4.Margin = new Padding(2, 2, 2, 2);
            panel4.Name = "panel4";
            panel4.Size = new Size(101, 38);
            panel4.TabIndex = 22;
            // 
            // listView1
            // 
            listView1.Location = new Point(7, 32);
            listView1.Margin = new Padding(2, 2, 2, 2);
            listView1.Name = "listView1";
            listView1.Size = new Size(188, 322);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // SVstart
            // 
            SVstart.BackColor = SystemColors.GradientInactiveCaption;
            SVstart.BackgroundImageLayout = ImageLayout.Zoom;
            SVstart.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point);
            SVstart.Location = new Point(2, 364);
            SVstart.Margin = new Padding(2, 2, 2, 2);
            SVstart.Name = "SVstart";
            SVstart.Size = new Size(94, 40);
            SVstart.TabIndex = 22;
            SVstart.Text = "서버시작";
            SVstart.UseVisualStyleBackColor = false;
            SVstart.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonHighlight;
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(listView1);
            panel2.Controls.Add(SVstop);
            panel2.Controls.Add(SVstart);
            panel2.Controls.Add(chatterbox);
            panel2.Location = new Point(0, 48);
            panel2.Margin = new Padding(2, 2, 2, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(202, 412);
            panel2.TabIndex = 18;
            panel2.Paint += panel2_Paint;
            // 
            // SVstop
            // 
            SVstop.BackColor = SystemColors.ControlDark;
            SVstop.BackgroundImageLayout = ImageLayout.Zoom;
            SVstop.Font = new Font("맑은 고딕", 9F, FontStyle.Bold, GraphicsUnit.Point);
            SVstop.Location = new Point(98, 364);
            SVstop.Margin = new Padding(2, 2, 2, 2);
            SVstop.Name = "SVstop";
            SVstop.Size = new Size(94, 40);
            SVstop.TabIndex = 25;
            SVstop.Text = "서버종료";
            SVstop.UseVisualStyleBackColor = false;
            // 
            // chatterbox
            // 
            chatterbox.AutoSize = true;
            chatterbox.BackColor = SystemColors.Window;
            chatterbox.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point);
            chatterbox.Location = new Point(14, 9);
            chatterbox.Margin = new Padding(2, 0, 2, 0);
            chatterbox.Name = "chatterbox";
            chatterbox.Size = new Size(144, 21);
            chatterbox.TabIndex = 22;
            chatterbox.Text = "클라이언트 리스트";
            // 
            // imgSend
            // 
            imgSend.BackColor = SystemColors.Window;
            imgSend.BackgroundImage = Properties.Resources.사진보내기_버튼;
            imgSend.BackgroundImageLayout = ImageLayout.Zoom;
            imgSend.FlatStyle = FlatStyle.Popup;
            imgSend.Location = new Point(200, 425);
            imgSend.Margin = new Padding(2, 2, 2, 2);
            imgSend.Name = "imgSend";
            imgSend.Size = new Size(37, 33);
            imgSend.TabIndex = 21;
            imgSend.UseVisualStyleBackColor = false;
            imgSend.Click += imgSend_Click;
            // 
            // msgSend
            // 
            msgSend.BackColor = SystemColors.ControlLightLight;
            msgSend.BackgroundImage = Properties.Resources.보내기_버튼;
            msgSend.BackgroundImageLayout = ImageLayout.Zoom;
            msgSend.FlatStyle = FlatStyle.Flat;
            msgSend.Location = new Point(529, 425);
            msgSend.Margin = new Padding(2, 2, 2, 2);
            msgSend.Name = "msgSend";
            msgSend.Size = new Size(39, 33);
            msgSend.TabIndex = 20;
            msgSend.UseVisualStyleBackColor = false;
            msgSend.Click += msgSend_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(236, 425);
            textBox1.Margin = new Padding(2, 2, 2, 2);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(293, 34);
            textBox1.TabIndex = 19;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ControlText;
            panel3.Location = new Point(236, 426);
            panel3.Margin = new Padding(2, 2, 2, 2);
            panel3.Name = "panel3";
            panel3.Size = new Size(292, 1);
            panel3.TabIndex = 0;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(204, 48);
            richTextBox1.Margin = new Padding(2, 2, 2, 2);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(363, 374);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // serverform_chatting
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(768, 499);
            Controls.Add(richTextBox1);
            Controls.Add(panel3);
            Controls.Add(imgSend);
            Controls.Add(msgSend);
            Controls.Add(textBox1);
            Controls.Add(panel2);
            Controls.Add(customer_information);
            Controls.Add(Below_bar);
            Controls.Add(panel1);
            Margin = new Padding(2, 2, 2, 2);
            Name = "serverform_chatting";
            Text = "serverform_chatting";
            Load += serverform_chatting_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            customer_information.ResumeLayout(false);
            customer_information.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button sv_search;
        private Label CSmain;
        private Panel Below_bar;
        private Panel customer_information;
        private Panel panel2;
        private Button imgSend;
        private Button msgSend;
        private TextBox textBox1;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Label chatterbox;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Label customer_info;
        private Label label1;
        private RichTextBox richTextBox1;
        private Button SVstart;
        private ListView listView1;
        private FolderBrowserDialog folderBrowserDialog1;
        private Button SVstop;
    }
}