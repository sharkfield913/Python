﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCPpj_main
{
    public partial class CSRform : Form
    {
        TcpClient client;
        StreamReader Reader;
        StreamWriter Writer;
        NetworkStream stream;
        Thread ReceiveThread;
        bool Connected;
        // private delegate void AddTextDelegate(string strText);


        public CSRform()
        {
            InitializeComponent();
        }

        private void CSmain_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CSRform_Load(object sender, EventArgs e)
        {
            try
            {
                client = new TcpClient();
                client.Connect(IPAddress.Parse("127.0.0.1"), 9000);

                stream = client.GetStream();
                Connected = true;
                richTextBox1.AppendText("Connected to Server!" + "\r\n");

                Reader = new StreamReader(stream);
                Writer = new StreamWriter(stream);

                // 로그인 타입 전송
                Writer.WriteLine("admin");
                Writer.Flush();

                ReceiveThread = new Thread(Receive);
                ReceiveThread.Start();
            }
            catch (Exception)
            {
                Console.WriteLine("연결 실패");
                Disconnect();
            }
        }

        private void CSRform_Closing(object sender, CancelEventArgs e)
        {
            Disconnect();
        }
        private void Disconnect()
        {
            Connected = false;
            if (Reader != null) Reader.Close();
            if (Writer != null) Writer.Close();
            if (client != null) client.Close();
            if (ReceiveThread != null) ReceiveThread.Abort();
        }
        private void Receive()
        {
            //AddTextDelegate AddText = new AddTextDelegate(UpdateRichTextBox);

            while (Connected)
            {
                Thread.Sleep(1);

                if (stream.CanRead)
                {
                    string tempStr = Reader.ReadLine();

                    if (!string.IsNullOrEmpty(tempStr))
                    {
                        AppendText("<- Server: " + tempStr + "\r\n");
                    }
                }
            }
        }
        private void AppendText(string text)
        {
            if (richTextBox1.InvokeRequired)
            {
                Invoke(new Action<string>(AppendText), text);
            }
            else
            {
                richTextBox1.AppendText(text);
            }
        }
        private void UpdateRichTextBox(string text)
        {
            richTextBox1.AppendText(text);
        }
        private readonly object sendLock = new object();
        private void msgSend_Click(object sender, EventArgs e)
        {
            lock (sendLock)
            {
                string message = textBox1.Text;

                if (!string.IsNullOrEmpty(message))
                {
                    // 이미지 파일이 선택되었는지 확인
                    if (File.Exists(message))
                    {
                        // 이미지 파일이면 파일을 전송
                        byte[] fileBytes = File.ReadAllBytes(message);
                        stream.Write(fileBytes, 0, fileBytes.Length);
                    }
                    else
                    {
                        // 이미지 파일이 아닌 경우에만 메시지를 전송
                        richTextBox1.AppendText("Me: " + message + "\r\n");
                        Writer.WriteLine(message);
                        Writer.Flush();
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void imgSend_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg;*.gif;*.bmp)|*.png;*.jpg;*.jpeg;*.gif;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = openFileDialog.FileName;
                textBox1.Text = fileName;
            }
        }
    }
}
