﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TCPpj_main
{
    public partial class ImageSelect : Form
    {
        public ImageSelect()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            // 이미지 파일만 필터링
            openFileDialog.Filter = "이미지 파일|*.jpg;*.jpeg;*.png;*.gif;*.bmp";

            // 사용자가 이미지 파일을 선택했을 때
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // 선택한 파일 경로로부터 이미지를 로드
                Image image = Image.FromFile(openFileDialog.FileName);

                // 이미지 크기를 300x300으로 조정
                Image resizedImage = ResizeImage(image, 300, 300);

                // pictureBox1에 이미지 표시
                pictureBox1.Image = resizedImage;

                // pictureBox1 크기 고정
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;

                // label1 텍스트 사라지도록 설정
                label1.Visible = false;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private Image ResizeImage(Image image, int width, int height)
        {
            Bitmap resizedImage = new Bitmap(width, height);
            using (Graphics graphics = Graphics.FromImage(resizedImage))
            {
                graphics.DrawImage(image, 0, 0, width, height);
            }
            return resizedImage;
        }
    }
}
