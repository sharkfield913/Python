﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;

namespace ServerForm
{
    public partial class serverform_chatting : Form
    {
        TcpListener Server;
        List<TcpClient> CounselorList = new List<TcpClient>();  // 상담사 리스트
        List<TcpClient> UserList = new List<TcpClient>();  // 유저 리스트
        TcpClient CurrentCounselor;  // 현재 상담사
        Dictionary<TcpClient, TcpClient> ChatPairs = new Dictionary<TcpClient, TcpClient>();

        Thread ReceiveThread;
        bool Connected;
        Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        private delegate void AddTextDelegate(string strText);

        [DllImport("Gdi32,dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (
                    int nLeft,
                    int nTop,
                    int nRight,
                    int nBottom,
                    int nWidthEllipse,
                    int nHeightEllipse
            );

        public serverform_chatting()
        {
            InitializeComponent();
        }

        private void serverform_chatting_Load(object sender, EventArgs e)
        {
            serverSocket.Bind(new IPEndPoint(IPAddress.Any, 9000));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Thread ListenThread = new Thread(new ThreadStart(Listen));
            ListenThread.Start();
        }

        private void Listen()
        {
            try
            {
                // 1. chatting room에 text 추가 delegate 함수
                AddTextDelegate AddText = new AddTextDelegate(richTextBox1.AppendText);

                // 2. Server Setting
                serverSocket.Listen(50);
                Invoke(AddText, "Server Start" + "\r\n");

                while (true)
                {
                    Socket clientSocket = serverSocket.Accept();
                    Invoke(AddText, "Connected to Client" + "\r\n");

                    TcpClient client = new TcpClient();
                    client.Client = clientSocket;

                    StreamReader reader = new StreamReader(client.GetStream());
                    string loginType = reader.ReadLine();  // 클라이언트의 로그인 타입 수신

                    lock (CounselorList)  // EmptyCList 접근 동기화
                    {
                        if (loginType == "admin")
                        {
                            CounselorList.Add(client);  // 상담자일 경우 빈 클라이언트 리스트에 추가
                        }
                        else if (loginType == "user")
                        {
                            if (UserList.Count >= 2)
                            {
                                StreamWriter writer = new StreamWriter(client.GetStream());
                                writer.WriteLine("채팅방에 이미 2명이 입장했습니다.");
                                writer.Flush();

                                client.Close();
                                continue;
                            }
                            lock (UserList)  // UserList 접근 동기화
                            {
                                UserList.Add(client);  // 유저일 경우 유저 리스트에 추가
                            }

                            // 연결된 상담사가 있는지 확인하고 연결 시도
                            if (CounselorList.Count > 0)
                            {
                                TcpClient counselor = CounselorList.First();  // 가장 앞에 있는 상담사와 연결
                                CounselorList.RemoveAt(0);  // 연결된 상담사를 리스트에서 제거
                                ChatPairs.Add(counselor, client);// 상담사와 유저를 매칭하여 채팅 페어 추가
                                ConnectUserWithCounselor(client);  // 상담사와 유저 연결 처리
                                StreamWriter counselorWriter = new StreamWriter(counselor.GetStream());
                                counselorWriter.WriteLine("상담이 시작되었습니다.");
                                counselorWriter.Flush();

                                StreamWriter userWriter = new StreamWriter(client.GetStream());
                                userWriter.WriteLine("상담이 시작되었습니다.");
                                userWriter.Flush();
                            }
                            else
                            {
                                StreamWriter writer = new StreamWriter(client.GetStream());
                                writer.WriteLine("상담사가 없습니다. 나중에 다시 시도해주세요.");
                                writer.Flush();

                                client.Close();
                            }
                        }
                        else
                        {
                            StreamWriter writer = new StreamWriter(client.GetStream());
                            writer.WriteLine("알 수 없는 유형");
                            writer.Flush();

                            client.Close();
                        }
                    }
                }
            }

            catch (Exception)
            {
                MessageBox.Show("오류");
            }
        }

        private void ConnectUserWithCounselor(TcpClient user)
        {
            TcpClient counselor = null;
            try
            {
                StreamWriter userWriter = new StreamWriter(user.GetStream());
                userWriter.WriteLine("연결되었습니다.");
                userWriter.Flush();

                // 상담사가 없으면 대기
                if (CounselorList.Count == 0)
                {
                    StreamWriter writer = new StreamWriter(user.GetStream());
                    writer.WriteLine("상담사가 없습니다. 나중에 다시 시도해주세요.");
                    writer.Flush();
                    return;
                }

                
                // 첫 번째 상담사와 연결
                lock (UserList)  // UserList 접근 동기화
                {
                    UserList.Add(user);  // 유저를 유저 리스트에 추가
                }

                lock (CounselorList)  // CounselorList 접근 동기화
                {
                    counselor = CounselorList[0];
                    CounselorList.RemoveAt(0);
                }

                StreamWriter counselorWriter = new StreamWriter(counselor.GetStream());
                counselorWriter.WriteLine("연결되었습니다.");
                counselorWriter.Flush();

                // 상담사와 유저의 채팅 처리
                Thread userThread = new Thread(() => HandleUser(user, counselor));
                userThread.Start();

                Thread counselorThread = new Thread(() => HandleCounselor(counselor, user));
                counselorThread.Start();
            }
            catch (Exception)
            {
                counselor.Close();
                user.Close();
            }
        }

        private async Task HandleUser(TcpClient user, TcpClient counselor)
        {
            try
            {
                StreamReader reader = new StreamReader(counselor.GetStream());
                StreamWriter userWriter = new StreamWriter(user.GetStream());

                while (true)
                {
                    string counselorMessage = await reader.ReadLineAsync();
                    if (counselorMessage != null)
                    {
                        await userWriter.WriteLineAsync("상담사: " + counselorMessage);
                        await userWriter.FlushAsync();
                    }
                    else
                    {
                        // 상담사가 연결을 끊었을 때 처리할 코드 추가
                        break;
                    }
                }
            }
            catch (Exception)
            {
                counselor.Close();
                user.Close();
            }
        }

        private async Task HandleCounselor(TcpClient counselor, TcpClient user)
        {
            try
            {
                StreamReader userReader = new StreamReader(user.GetStream());
                StreamWriter counselorWriter = new StreamWriter(counselor.GetStream());

                while (true)
                {
                    string userMessage = await userReader.ReadLineAsync();
                    if (userMessage != null)
                    {
                        await counselorWriter.WriteLineAsync("유저: " + userMessage);
                        await counselorWriter.FlushAsync();
                    }
                }
            }
            catch (Exception)
            {
                counselor.Close();
                user.Close();
            }
        }

        private void msgSend_Click(object sender, EventArgs e)
        {
            string message = textBox1.Text;
            foreach(var pair in ChatPairs)
            {
                TcpClient counselor = pair.Key;
                TcpClient user = pair.Value;
                try
                {
                    StreamWriter counselorWriter = new StreamWriter(counselor.GetStream());
                    counselorWriter.WriteLine("상담사: " + message);
                    counselorWriter.Flush();

                    StreamWriter userWriter = new StreamWriter(user.GetStream());
                    userWriter.WriteLine("유저: " + message);
                    userWriter.Flush();
                }
                catch (Exception)
                {
                    counselor.Close();
                    user.Close();
                    ChatPairs.Remove(counselor);
                }
            }
            // char room에 sender message 추가
           // richTextBox1.AppendText("Me: " + textBox1.Text + "\r\n");

           // foreach (TcpClient client in UserList)
           // {
           //     StreamWriter writer = new StreamWriter(client.GetStream());
           //     writer.WriteLine(textBox1.Text);
           //     writer.Flush();
           // }

            textBox1.Clear();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddChatText(string strText)
        {
            richTextBox1.AppendText(strText);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // panel1_Paint 이벤트 핸들러 내용을 여기에 작성하세요.
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {
            // panel8_Paint 이벤트 핸들러 내용을 여기에 작성하세요.
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DisplayClientList(List<TcpClient> clientList)
        {
            if (listView1.InvokeRequired)
            {
                // UI 스레드에 대리자를 전달하여 실행
                listView1.Invoke(new Action<List<TcpClient>>(DisplayClientList), clientList);
            }
            else
            {
                // ListView를 초기화
                listView1.Items.Clear();

                // 클라이언트 리스트를 ListView에 추가
                foreach (TcpClient client in clientList)
                {
                    // 클라이언트의 IP 주소와 포트 번호를 가져옴
                    string ipAddress = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
                    int port = ((IPEndPoint)client.Client.RemoteEndPoint).Port;

                    // ListView에 항목 추가
                    ListViewItem item = new ListViewItem(ipAddress);
                    item.SubItems.Add(port.ToString());
                    listView1.Items.Add(item);
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
